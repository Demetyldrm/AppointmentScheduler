package yildirim.dbclientapp.dao;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import yildirim.dbclientapp.model.Users;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class DBUsers extends Users {

    public DBUsers(int userID, String userName, String userPassword) {
        super();
    }

    /**
     * This method validates the user for the login form.
     *
     * @param password
     * @param username
     */
    public static int validateUser(String username, String password) {
        try {
            String sqlQuery = "SELECT * FROM users WHERE user_name = '" + username + "' AND password = '" + password + "'";

            PreparedStatement ps = JDBC.getConnection().prepareStatement(sqlQuery);
            ResultSet rs = ps.executeQuery();
            rs.next();
            if (rs.getString("User_Name").equals(username)) {
                if (rs.getString("Password").equals(password)) {
                    return rs.getInt("User_ID");

                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1;
    }

    /**
     * Method to pull in all user data to getAllUsers observablelist.
     *
     * @return usersObservableList
     * @throws SQLException
     */
    public static ObservableList<DBUsers> getAllUsers() throws SQLException {
        ObservableList<DBUsers> usersObservableList = FXCollections.observableArrayList();
        String sql = "SELECT * from users";
        PreparedStatement ps = JDBC.getConnection().prepareStatement(sql);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int userID = rs.getInt("User_ID");
            String userName = rs.getString("User_Name");
            String userPassword = rs.getString("Password");
            DBUsers user = new DBUsers(userID, userName, userPassword);
            usersObservableList.add(user);
        }
        return usersObservableList;
    }
}