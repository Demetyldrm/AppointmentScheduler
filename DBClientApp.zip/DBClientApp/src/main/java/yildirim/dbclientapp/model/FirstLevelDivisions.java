package yildirim.dbclientapp.model;

public class FirstLevelDivisions {
    private int divisionID;
    private String divisionName;
    public int country_ID;

    public FirstLevelDivisions(int divisionID, String divisionName, int countryId) {
    }

    /**
     * @param divisionID
     * @param country_ID
     * @param divisionName
     */
    public void firstLevelDivision(int divisionID, String divisionName, int country_ID) {
        this.divisionID = divisionID;
        this.divisionName = divisionName;
        this.country_ID = country_ID;
    }

    /**
     * @return divisionID
     */
    public int getDivisionID() {

        return divisionID;
    }

    /**
     * @return divisionName
     */
    public String getDivisionName() {

        return divisionName;
    }

    /**
     * @return country_ID
     */
    public int getCountry_ID() {

        return country_ID;
    }

    @Override
    public String toString() {
        return (divisionName);
    }

}
