package yildirim.dbclientapp.main;

import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import yildirim.dbclientapp.dao.DBCountries;
import yildirim.dbclientapp.model.Countries;

import java.net.URL;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    @FXML
    private Label welcomeText;

    @FXML
    protected void onHelloButtonClick() {
        welcomeText.setText("Welcome to JavaFX Application!");
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

    }

    public void showMe(ActionEvent actionEvent) throws SQLException {
        ObservableList<DBCountries> countriesObservableList = DBCountries.getCountries();
        for (Countries C : countriesObservableList) {
            System.out.println("Country id: " + C.getCountryID() + " Name : " + C.getCountryName());
        }
    }
}