package yildirim.dbclientapp.controller;

public class LoginScreen {
}
